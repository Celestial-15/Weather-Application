
INSTALLED_APPS = [
    # other apps
    'weather',
]

# Other default settings (omitted for brevity)
        