
import requests
from django.shortcuts import render
from .models import WeatherSearch

def get_weather(request):
    weather_data = {{}}
    if 'location' in request.GET:
        location = request.GET['location']
        api_url = f"https://api.openweathermap.org/data/2.5/weather?q={{location}}&appid=YOUR_API_KEY&units=metric"
        response = requests.get(api_url)
        if response.status_code == 200:
            weather_data = response.json()
            WeatherSearch.objects.create(location=location)
        else:
            weather_data = {{'error': 'Location not found'}}
    return render(request, 'weather/weather.html', {{'weather_data': weather_data}})
        